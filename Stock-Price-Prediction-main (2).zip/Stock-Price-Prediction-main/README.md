# Corizo - Minor Project on Stock-Price-Prediction
Corizo - Minor Project On Stock Price Prediction Using Long Short-Term Memory(LSTM) Networks.

## Attribute Information :

**Open** - The price the stock opened at.<br/>
**High** - The highest price during the day.</br>
**Low** - The lowest price during the day.</br>
**Close** - The closing price on the trading day.</br>
**Adj Close** - The price of the stock after paying off the dividends.</br>
**Volume** - How many shares were tradedx.</br>

![stock](https://user-images.githubusercontent.com/101797651/230879127-ba158c63-5690-4db9-a89e-f4ca9903bd42.png)

   **Actual Price vs Predicted Price of the stock**
